<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/media.yaml',
    'modified' => 1484450393,
    'data' => [
        
    ]
];
