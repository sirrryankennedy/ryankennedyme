---
title: Just Some Text Today
date: 13:34 06/23/2014 
continue_link: false
author: Andy Rhuker
body_classes: header-lite fullwidth blogstyling
taxonomy:
    category: blog
    tag: [journal]
---

> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultricies tristique nulla et mattis. Phasellus id massa eget nisl congue blandit sit amet id ligula. Praesent et nulla eu augue tempus sagittis. Mauris faucibus nibh et nibh cursus in vestibulum sapien egestas. Curabitur ut lectus tortor. Sed ipsum eros, egestas ut eleifend non, elementum vitae eros. 
> -- <cite> Ronald Wade</cite>

