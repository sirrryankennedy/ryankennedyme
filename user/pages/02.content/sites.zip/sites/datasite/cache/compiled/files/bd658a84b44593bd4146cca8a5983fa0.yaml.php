<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://optimus/optimus.yaml',
    'modified' => 1484465145,
    'data' => [
        'enabled' => true,
        'license_key' => '16LCMH468PD7KI0R1AKOTJRF'
    ]
];
