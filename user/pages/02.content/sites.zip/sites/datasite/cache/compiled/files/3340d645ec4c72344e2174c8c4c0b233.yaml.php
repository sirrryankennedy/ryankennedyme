<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/plugins/feed.yaml',
    'modified' => 1484455423,
    'data' => [
        'enabled' => false,
        'limit' => 10,
        'description' => 'My Feed Description',
        'lang' => 'en-us',
        'length' => 500
    ]
];
