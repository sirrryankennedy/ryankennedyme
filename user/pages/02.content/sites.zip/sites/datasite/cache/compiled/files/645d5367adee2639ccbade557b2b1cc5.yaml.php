<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://image-collage/image-collage.yaml',
    'modified' => 1484464775,
    'data' => [
        'enabled' => true,
        'column' => 2,
        'border_size' => 10,
        'image_width' => 900
    ]
];
