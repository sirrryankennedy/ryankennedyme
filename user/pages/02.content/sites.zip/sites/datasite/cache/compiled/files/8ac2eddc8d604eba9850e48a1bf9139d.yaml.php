<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://feed/feed.yaml',
    'modified' => 1485401017,
    'data' => [
        'enabled' => true,
        'limit' => 10,
        'description' => 'My Feed Description',
        'lang' => 'en-us',
        'length' => 500
    ]
];
