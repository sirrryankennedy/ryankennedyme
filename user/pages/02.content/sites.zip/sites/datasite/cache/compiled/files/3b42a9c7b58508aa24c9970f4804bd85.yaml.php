<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/plugins/optimus.yaml',
    'modified' => 1484465310,
    'data' => [
        'enabled' => false,
        'license_key' => '16LCMH468PD7KI0R1AKOTJRF'
    ]
];
