---
title: Service Highlights
menu: Highlights
class: big
features:
	- header: First Service
	  text: "Sed posuere consectetur est at lobortis. Vivamus aoreet faucibus dolor auctor."
	  icon: comment-o
	  linkurl: "http://www.getgrav.org" 
	  linktext: "Find Out More"
	- header: Second Service
	  text: "Duis mollis, est non commodo eget urna mollis ornare vel eu leo faucibus."
	  icon: heart-o
	  linkurl: "http://www.getgrav.org" 
	  linktext: "Find Out More"
	- header: Third Service
	  text: "Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor."
	  icon: star-o
	  linkurl: "http://www.getgrav.org" 
	  linktext: "Find Out More"
---

## We are a Small Team Doing Big Things!

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent justo ligula, interdum ut lobortis quis, interdum vitae metus. Proin fringilla metus non nulla cursus, sit amet rutrum est pretium.. 

___