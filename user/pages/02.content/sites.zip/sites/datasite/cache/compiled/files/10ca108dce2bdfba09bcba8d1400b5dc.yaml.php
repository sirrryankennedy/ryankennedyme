<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://deliver/deliver.yaml',
    'modified' => 1484450453,
    'data' => [
        'enabled' => true,
        'dropdown' => [
            'enabled' => false
        ],
        'sticky_menu' => [
            'enabled' => false
        ]
    ]
];
