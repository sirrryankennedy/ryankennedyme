---
title: Home
blog_url: Home
menu: Home
body_classes: header-lite fullwidth blogstyling
bg_color: "#B4B093"

sitemap:
    changefreq: monthly
    priority: 1.03

content:
    items: '@self.descendants'
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true

feed:
    description: Sample Blog Description
    limit: 10

pagination: true
---

# Homepage
