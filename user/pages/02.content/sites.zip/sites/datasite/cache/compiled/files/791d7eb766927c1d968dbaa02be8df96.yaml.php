<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/site.yaml',
    'modified' => 1485403269,
    'data' => [
        'title' => 'Data Intellego',
        'author' => [
            'name' => 'Ryan Kennedy',
            'email' => 'dataintellego@gmail.com',
            'copyright' => 'Copyright 2017 Data Intellego. All Rights Reserved.'
        ],
        'social' => [
            0 => [
                'url' => 'https://twitter.com/dataintellego',
                'icon' => 'twitter'
            ],
            1 => [
                'url' => 'https://www.facebook.com/dataintellego',
                'icon' => 'facebook'
            ],
            2 => [
                'url' => 'blog.rss',
                'icon' => 'rss'
            ]
        ],
        'contact' => [
            'address' => [
                0 => [
                    'line' => '222 Ave C South'
                ],
                1 => [
                    'line' => 'Saskatoon, Saskatchewan'
                ],
                2 => [
                    'line' => 'Canada S7K 2N5'
                ]
            ],
            'gps' => '1.306.222.3456'
        ],
        'othermenu' => [
            0 => [
                'text' => 'About',
                'url' => 'about'
            ],
            1 => [
                'text' => 'Privacy Policy',
                'url' => '#'
            ],
            2 => [
                'text' => 'Contact',
                'url' => 'contact'
            ]
        ],
        'quicklinks' => [
            0 => [
                'text' => 'Home',
                'url' => 'base_url:/'
            ],
            1 => [
                'text' => 'About',
                'url' => 'base_url:about'
            ],
            2 => [
                'text' => 'Services',
                'url' => 'base_url:services'
            ],
            3 => [
                'text' => 'Contact Us',
                'url' => 'base_url:contact'
            ],
            4 => [
                'text' => 'Facebook',
                'url' => 'https://www.facebook.com/dataintellego'
            ],
            5 => [
                'text' => 'Twitter',
                'url' => 'https://twitter.com/dataintellego'
            ]
        ],
        'taxonomies' => [
            0 => 'category',
            1 => 'tag'
        ],
        'blog' => [
            'route' => '/home'
        ],
        'metadata' => [
            'description' => 'My Deliver Site'
        ],
        'summary' => [
            'size' => 300
        ],
        'routes' => [
            '/something/else' => '/blog/sample-3',
            '/another/one/here' => '/blog/sample-3',
            '/new/*' => '/blog/*'
        ],
        'header_options' => [
            'arrows' => 'true',
            'autoslide' => 'false',
            'autoslideHoverStop' => 'false',
            'interval' => '2000',
            'loop' => 'false',
            'transition' => 'zoom',
            'itemsForSlide' => '0',
            'touch' => 'true',
            'swipe' => 'true'
        ],
        'footer' => [
            'description' => '<b>Data Intellego</b>, Latin for <b><i>I understand data</i></b>, aims to spread knowledge through data visualization.',
            'contact_title' => 'Contact Info',
            'links_title' => 'Quick Links',
            'newsletter_title' => 'Newsletter',
            'newsletter_description' => 'Etiam porta sem malesuada magna mollis euismod.',
            'copyright_text' => 'Copyright 2017 Data Intellego. All Rights Reserved.',
            'feedburner' => ''
        ]
    ]
];
