---
title: Resume | Ryan Kennedy

content:
  items: '@self.modular'
  order:
    by: default
    dir: asc
    custom:
      - _showcase
---