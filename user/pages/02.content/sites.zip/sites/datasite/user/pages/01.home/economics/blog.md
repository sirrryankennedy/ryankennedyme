---
title: Economics
blog_url: blog/economics
body_classes: header-lite fullwidth blogstyling
bg_color: "#B4B093"
published: false

sitemap:
    changefreq: monthly
    priority: 1.03

content:
    items: @self.siblings
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true


pagination: true
---

# Economics
