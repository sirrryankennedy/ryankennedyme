<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/plugins/breadcrumbs/breadcrumbs.yaml',
    'modified' => 1477190484,
    'data' => [
        'enabled' => true,
        'show_all' => true,
        'built_in_css' => true,
        'include_home' => true,
        'icon_home' => '',
        'icon_divider_classes' => 'fa fa-angle-right',
        'link_trailing' => false
    ]
];
