<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/plugins/subscriber/subscriber.yaml',
    'modified' => 1485401034,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'email_from' => 'user@example.com',
        'email_to' => 'user@example.com'
    ]
];
