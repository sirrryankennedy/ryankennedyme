<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/accounts/ryan.yaml',
    'modified' => 1484450422,
    'data' => [
        'email' => 'dataintellego@gmail.com',
        'fullname' => 'Ryan Kennedy',
        'title' => 'Administrator',
        'state' => 'enabled',
        'access' => [
            'admin' => [
                'login' => true,
                'super' => true
            ],
            'site' => [
                'login' => true
            ]
        ],
        'hashed_password' => '$2y$10$QsrN45Gr2G1xij4JavMgruGxb9EbVISfBtpWCFxPjEBHaF.7i/RYy'
    ]
];
