<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/plugins/image-collage.yaml',
    'modified' => 1484465325,
    'data' => [
        'enabled' => true,
        'column' => 2,
        'border_size' => 10,
        'image_width' => 900
    ]
];
