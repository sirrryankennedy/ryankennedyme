# v1.1.0
## 11/18/2015

1. [](#new)
    * SimpleForm replaced with Forms plugin
2. [](#bugfix)
    * Admin plugin bugfixes

# v1.0.3
## 09/18/2015

1. [](#new)
    * Landing page for SimpleForm

# v1.0.2
## 05/09/2015

1. [](#improved)
    * Fix for bottom menu links

# v1.0.1
## 02/10/2015

1. [](#new)
    * ChangeLog started...
