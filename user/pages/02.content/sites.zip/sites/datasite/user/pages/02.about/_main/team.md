---
title: Team
members:
    - name: Michael Turner
      image: michael.jpg
      title: President
      info: "Curabitur blandit tempus porttitor. Donec id elit non mi porta gravida at eget metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus."
      social_twitter: "#"
      social_facebook: "#"
      social_feed: "#"
    - name: John Smith
      image: john.jpg
      title: Programmer
      info: "Curabitur blandit tempus porttitor. Donec id elit non mi porta gravida at eget metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus."
      social_twitter: "#"
      social_facebook: "#"
      social_feed: "#"
    - name: Ashley Hunter
      image: ashley.jpg
      title: Human Resources
      info: "Curabitur blandit tempus porttitor. Donec id elit non mi porta gravida at eget metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus."
      social_twitter: "#"
      social_facebook: "#"
      social_feed: "#"
    - name: Tim Bird
      image: tim.jpg
      title: Designer
      info: "Curabitur blandit tempus porttitor. Donec id elit non mi porta gravida at eget metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus."
      social_twitter: "#"
      social_facebook: "#"
      social_feed: "#"
---
## Meet our team
Sed posuere consectetur est at lobortis. Nullam id dolor id nibh ultricies vehicula ut id elit. Etiam porta sem malesuada magna mollis euismod.
