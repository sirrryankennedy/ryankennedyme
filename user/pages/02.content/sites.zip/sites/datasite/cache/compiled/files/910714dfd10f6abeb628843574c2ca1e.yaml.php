<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/config/streams.yaml',
    'modified' => 1484450393,
    'data' => [
        
    ]
];
