---
title: Contact
class: borderbottom
process:
  twig: true
---

#### Our Location
We just moved to our new location down the block right beside Subway.

9 - 3815 Thatcher Avenue <br />
Saskatoon, Saskatchewan <br />
S7R 1A3 <br />

#### Contact Information
**Email:**  		 		info@yastech.ca <br />
**Primary Phone:**   		1 (306) 249 - 9609 <br />
**Alternate Phone:**   		1 (306) 249 - 9612 <br />
**Fax:**   				1 (306) 931 - 6739 <br />

#### Office Hours
Monday - Friday			8 am - 5 pm <br />
Saturday - Sunday			Closed <br />
Holidays					Closed <br />

* Feel free to email or call us after hours.
