<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/public/datasite/user/plugins/taxonomylist/taxonomylist.yaml',
    'modified' => 1477190488,
    'data' => [
        'enabled' => true,
        'route' => '/blog'
    ]
];
